-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Oct 21, 2022 at 01:29 PM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 8.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dashboard`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_user`
--

CREATE TABLE `tbl_user` (
  `id` bigint(20) NOT NULL,
  `name` varchar(128) NOT NULL,
  `email` varchar(128) NOT NULL,
  `password` varchar(256) NOT NULL,
  `phoneno` varchar(64) NOT NULL,
  `role` varchar(64) NOT NULL,
  `profile_image` varchar(256) DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT 1,
  `is_online` tinyint(1) NOT NULL DEFAULT 1,
  `is_deleted` tinyint(1) NOT NULL DEFAULT 0,
  `last_login` datetime DEFAULT NULL,
  `forgotpassword_token` varchar(128) DEFAULT NULL,
  `forgotpassword_date` datetime DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_user`
--

INSERT INTO `tbl_user` (`id`, `name`, `email`, `password`, `phoneno`, `role`, `profile_image`, `is_active`, `is_online`, `is_deleted`, `last_login`, `forgotpassword_token`, `forgotpassword_date`, `created_at`, `updated_at`) VALUES
(1, 'husaing', 'hg@gmail.com', 'chintan1122', '8521252465', 'user', '../../assets/img/chintan.jpg', 1, 1, 0, '2022-10-21 10:23:35', 'Dashboard1', '2022-10-18 17:29:08', '2022-10-11 01:40:02', '2022-10-21 04:53:35'),
(2, 'anandswami', 'anandswami0912@gmail.com', 'Anand@1235', '8523232323', 'user', '../../assets/img/anand.jpg', 1, 0, 0, '2022-10-21 16:34:45', 'Dashboard2', '2022-10-20 13:56:03', '2022-10-11 02:00:07', '2022-10-21 11:04:55'),
(3, 'rahul', 'rahulmeenaglc847@gmail.com', 'Rahul@111', '7412589632', 'user', '../../assets/img/rahul.jpg', 1, 1, 0, '2022-10-12 16:42:17', 'Dashboard3', '2022-10-18 16:46:30', '2022-10-12 05:28:08', '2022-10-18 11:16:30'),
(9, 'husaingora', 'hg12@gmail.com', 'husain1122', '8523232323', 'user', '../../assets/img/husain.jpg', 1, 1, 0, '2022-10-20 16:28:19', NULL, NULL, '2022-10-20 06:35:09', '2022-10-20 11:58:04');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_user_token`
--

CREATE TABLE `tbl_user_token` (
  `id` bigint(20) NOT NULL,
  `user_id` bigint(20) NOT NULL,
  `token` varchar(64) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `insertdate` timestamp NOT NULL DEFAULT current_timestamp(),
  `updatetime` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_user_token`
--

INSERT INTO `tbl_user_token` (`id`, `user_id`, `token`, `insertdate`, `updatetime`) VALUES
(7, 2, '', '2022-10-15 12:01:34', '2022-10-21 11:04:55'),
(8, 9, 'bxm4uvxtqz5185benz6o8hn1ce2w39uuj44550zdeopc5osrfb339bhbiy7farkb', '2022-10-20 06:35:09', '2022-10-20 10:58:19'),
(9, 1, 'sonwz698kq4zfhowvvenj5fixb3vy4j15rxwrynw3biw1ydgckfb9uwq6z2wbqv3', '2022-10-21 04:42:56', '2022-10-21 04:53:35');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_user`
--
ALTER TABLE `tbl_user`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_user_token`
--
ALTER TABLE `tbl_user_token`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_user`
--
ALTER TABLE `tbl_user`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `tbl_user_token`
--
ALTER TABLE `tbl_user_token`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
