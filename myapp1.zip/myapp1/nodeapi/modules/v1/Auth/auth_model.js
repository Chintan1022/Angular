var con = require('../../../config/database');
var common = require('../../../config/common');
var emailTemplate = require('../../../config/template');

var Auth = {
    
    dashboard: function (req, callback) {

        con.query("SELECT COUNT(name)as usercount FROM tbl_user", function (err, result, fields) {
        
            if (!err && result[0]!=undefined) {
                callback('1', { keyword: 'rest_keywords_dashboard_details_success'}, result[0]);   

            } else {
                callback('0', { keyword: 'rest_keywords_dashboard_details_fail'}, null);   

            }
        });
    }, 

    //getuser profile
    userprofile: function (req, callback) {

        con.query("SELECT u.*,IFNULL(ut.token,'') as token FROM tbl_user u LEFT JOIN tbl_user_token as ut ON u.id = ut.user_id WHERE u.id = '" + req.user_id + "' AND u.is_deleted='0' GROUP BY u.id", function (err, result, fields) {
        
            if (!err && result[0]!=undefined) {
                callback('1', { keyword: 'rest_keywords_user_login_success'}, result[0]);   

            } else {
                callback('0', { keyword: 'rest_keywords_user_login_success'}, null);   

            }
        });
    }, 
  
    //userdetails
    userdetails: function (user_id, callback) {

        con.query("SELECT u.*,IFNULL(ut.token,'') as token FROM tbl_user u LEFT JOIN tbl_user_token as ut ON u.id = ut.user_id WHERE u.id = '" + user_id + "' AND u.is_deleted='0' GROUP BY u.id", function (err, result, fields) {
       
            if (!err && result.length > 0) {
                callback(result[0]);

            } else {
                callback(null);
            }
        });
    },

    //login
    checkLogin: function (request, callback) {
        
        con.query("SELECT * FROM tbl_user where  email= '" + request.email + "' AND is_deleted='0' AND is_active='1'", function (err, result, fields) {
            if (!err) {
              if(result[0] != undefined){
                    
                    
                    if(result[0].password === request.password){
                        
                        
                        var updparams = {
                            is_online: "1",
                            last_login: require('node-datetime').create().format('Y-m-d H:M:S'),
                            
                        }
                        
                            Auth.updateCustomer(result[0].id, updparams, function (userprofile, error) {
                                common.generateSessionCode(result[0].id, "Customer", function (Token) {    
                                   userprofile.token = Token
                                    callback('1', { keyword: 'rest_keywords_user_login_success', components: {}}, userprofile);   
                                });
                            });
                       
                    }else{
                        
                      
                        callback('0', {  keyword: "password_don't_match", components: {}  }, null); 
                    }
              }else{
               
                    if(request.social_id != undefined && request.login_type != 'S'){
                         callback('11', { keyword: 'text_user_login_new', components: {} }, null);
                    }else{
                         callback('0', { keyword: 'text_user_login_new', components: {} }, null);
                    }
            } 
            }else{
               
                    callback('0', { keyword: 'rest_keywords_invalid_email',components: {} }, null);
            }
               
          });          
   
    },
    
    //signup
    signUpUsers: function (request, callback) {
        Auth.checkUniqueFields(request, function (uniquecode, uniquemsg, isUnique) {

            if (isUnique) {

                var user = {
                    name:request.name,
                    email: request.email,
                    phoneno:request.phoneno,
                    password: request.password,
                    role:request.role,
                    is_online: "1",
                    //profile_image:request.profile_image,
                    last_login:require('node-datetime').create().format('Y-m-d H:M:S')
                };
                console.log(user)
                con.query('INSERT INTO tbl_user SET ?', user, function (err, result, fields) {
                    console.log(err)
                    if (!err) {
                        
                            Auth.userdetails(result.insertId, function (userprofile, err) {
                                common.generateSessionCode(result.insertId, user, function (Token) {  
                                    console.log("111",Token);
                    
                                    userprofile.token = Token;                             
                                    callback('1', {
                                        keyword: 'rest_keywords_user_signup_success',
                                        components: {}
                                    }, userprofile);
                                });
                            });
                        
                    } else {
                       
                        callback('0', {
                            keyword: 'rest_keywords_user_signup_failed',
                            components: {}
                        }, null);
                    }
                });

            } else {
                callback(uniquecode, uniquemsg, null);
            }
        });
    },

    //updatecustomer
    updateCustomer: function (user_id, upd_params, callback) {
        con.query("UPDATE tbl_user SET ? WHERE id = ? ", [upd_params, user_id], function (err, result, fields) {
            console.log(err);
            if (!err) {
                Auth.userdetails(user_id, function (response, err) {
                    callback(response);
                });
            } else {
                callback(null, err);
            }
        });
    },

    //forgotPassword
    forgotPassword: function (request, callback) {

        con.query("SELECT * FROM tbl_user where email='" + request.email + "' AND is_deleted='0' ", function (err, result, fields) {
            if (!err & result[0] != undefined) {
                 
                var updparams = {
                    forgotpassword_token: process.env.APP_NAME + result[0].id,
                    forgotpassword_date: require('node-datetime').create().format('Y-m-d H:M:S')
                }
                Auth.updateCustomer(result[0].id, updparams, function (isupdated) {

                    result[0].encoded_user_id = Buffer.from(result[0].id.toString()).toString('base64');
                    emailTemplate.forgot_password(result[0], function (forgotTemplate) {
                        common.send_email("Forgot Password", request.email, forgotTemplate, function (isSend) {
                            if (isSend) {
                                callback('1', {
                                    keyword: 'rest_keywords_user_forgot_password_success',
                                    components: {}
                                }, result[0]);
                            } else {
                                callback('0', {
                                    keyword: 'rest_keywords_user_forgot_password_failed',
                                    components: {}
                                }, result[0]);
                            }
                        });
                    });
                });
            } else {
                callback('0', {
                    keyword: 'rest_keywords_user_doesnot_exist',
                    components: {}
                }, null);
            }
        });
    },

    //changepassword
    changePassword: function (user_id, request, callback) {
        console.log(request)
        Auth.userdetails(user_id, function (userprofile) {
            console.log(userprofile)
            if (userprofile != null) {
                if (userprofile.password != request.oldPwd) {
                    callback('0', {
                        keyword: 'rest_keywords_user_old_password_incorrect',
                        components: {}
                    }, null);
                } else if (userprofile.password == request.newPwd) {
                    callback('0', {
                        keyword: 'rest_keywords_user_newold_password_similar',
                        components: {}
                    }, null);
                } else {
                    var updparams = {
                        password: request.newPwd
                    };
                    Auth.updateCustomer(user_id, updparams, function (userprofile) {
                        if (userprofile == null) {
                            callback('0', {
                                keyword: 'rest_keywords_something_went_wrong',
                                components: {}
                            }, null);
                        } else {
                            callback('1', {
                                keyword: 'rest_keywords_user_change_password_success',
                                components: {}
                            }, userprofile);
                        }
                    });
                }
            } else {
                
                callback('0', {
                    keyword: 'rest_keywords_userdetailsnot_found',
                    components: {}
                }, null);
            }
        });
    },

    //editProfile
     editUser: function (user_id, request, callback) {
        Auth.userdetails(user_id, function (userprofile) {
          
            if (userprofile != null) {

                var updparams = {
                    id:request.id,
                    name: request.name,
                    email:request.email,
                    phoneno:request.phoneno,  

                };

                Auth.updateCustomer(user_id, updparams, function (userprofile) {
                    if (userprofile == null) {
                        callback('0', {
                            keyword: 'rest_keywords_something_went_wrong',
                            components: {}
                        }, null);
                    } else {
                        callback('1', {
                            keyword: 'rest_keywords_profileupdate_success',
                            components: {}
                        }, userprofile);
                    }
                });

            } else {
                callback('0', {
                    keyword: 'rest_keywords_userdetailsnot_found',
                    components: {}
                }, null);
            }
        });
    },

    //getuserdetails
    getUserDetails:function(request,callback){

        var p = `select * from tbl_user`; 

        con.query(p,function(err,result){
            console.log(err)
        if(!err)
        {
            callback("1", {keyword: "rest_keywords_get_store_details_category_success",components: {},},result);
        }
        else
        {
            callback("0", {keyword: "rest_keywords_get_store_details_category_FAIL",components: {},},null);
        }
  
        })
    },

    //check unique fields
    checkUniqueFields: function (request,callback) {
        Auth.checkUniqueEmail(request, function (emailcode, emailmsg, emailUnique) {
            if (emailUnique) {
                callback(emailcode, emailmsg, emailUnique);
            } else {
                callback(emailcode, emailmsg, emailUnique);
            }
        });
        
    },

     //check unique email
    checkUniqueEmail: function ( request, callback) {

        if (request.email != undefined && request.email != '') {

           var uniqueEmail = "SELECT * FROM tbl_user WHERE email = '" + request.email + "' AND is_deleted='0' ";
            
            con.query(uniqueEmail, function (error, result, fields) {
                if (!error && result[0] != undefined) {
                    // alert("please enter new email")
                    callback('0', { keyword: 'rest_keywords_duplicate_email',  components: {} }, false);   
                } else {
                   
                    callback('1', "Success", true);
                }
            });

        } else {
            callback('1', "Success", true);
        }
    },

    //update user detail
    updateUserDetail: function (request, callback) {

        var updateparams = {
            name: request.name,
            email: request.email,
            phoneno:request.phoneno
                              
        };

        con.query("UPDATE tbl_user SET ? WHERE id = ? ", [updateparams, request.id], function (err, result, fields) {
            console.log(err)
            if(!err)
            {
                callback("1", {keyword: "rest_keywords_update_user_details_success",components: {},},result);
            }
            else
            {
                callback("0", {keyword: "rest_keywords_update_user_details_FAIL",components: {},},null);
            }
        });
    }, 
    
    //delete device
    deleteDevice: function (req, callback) {
       con.query("delete from tbl_user_token where user_id = '" + req.getid + "' ", function (err, result) {
            if (!err && result[0] != undefined) {
                callback("1", {keyword: "rest_keywords_userdevice_success",components: {},},result); 
            } else {
                callback("0", {keyword: "rest_keywords_userdevice_fail",components: {},},err); 
            }
        });
    },

    //delete user details
    deleteuser: function (request, callback) {

      con.query(`delete from tbl_user where id = ${request.getid}`, function (err, result, fields) {
            if (!err) {
                Auth.deleteDevice(request, function (deleteDevice, Error) {
                    if (deleteDevice != null){
                        callback("1", {keyword: "rest_keywords_delete_user_success",components: {},},deleteDevice);
                    }else{
                            callback("0", {keyword: "rest_keywords_delete_user_fail",components: {},},err); 
                        }
                    });
               
            } else {
                callback('0', {  keyword: 'rest_keywords_something_wrong',   components: {}}, err);
            }
        });
    },

    //getsingleuser
    getSingleUser: function (request, callback) {
    
        con.query(`select * from tbl_user where id = ${request.id}`, function (err, result, fields) {
            if (!err) {
                callback("1", {keyword: "rest_keywords_get_single_user_success",components: {},},result[0]);
            }
            else{
                 callback("0", {keyword: "rest_keywords_get_single_user_fail",components: {},},err); 
            }
        });
    },


}


module.exports = Auth;