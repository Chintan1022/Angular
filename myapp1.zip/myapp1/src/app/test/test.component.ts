import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'app-test',
  templateUrl: './test.component.html'
  ,
  styleUrls: ['./test.component.css']
})
export class TestComponent implements OnInit {

  @Input('parentData') public name: any;

  username:string="anand";

  myclasses="red";
  
  applycssclasses=false;
  
  paracolor='brown'; 

  color="orange";

  logintype="user"

  isLogIn : boolean = false;
  isLogOut : boolean = true; 

  displayname:boolean=false;
  
  presentDate = new Date(); 
  
  viewmode='map'

  public colors=['red','green','blue','yellow','brown'];

  price : number = 20000;

  decimalNum: number = 8.7589623898808; 

  decimalNum1: number = 0.8178;


  jsonData = { id: 1, name: { username: 'chintan soni' }} 
  
  constructor() { }

  ngOnInit(): void {
  }
  onclick(){
    console.log("hello")
    alert("hello World")
  }
  logmessage(value: any){
    console.log(value)
  }
  onAdd(){
    this.colors.push('cyan')
  }
  


}
