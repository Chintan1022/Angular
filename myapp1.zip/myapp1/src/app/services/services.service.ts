import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { data } from 'jquery';



@Injectable({
  providedIn: 'root'
})
export class ServicesService {
  body = ['key', 'val'];
  token = localStorage.getItem('token') || "";
  constructor(private http: HttpClient) { }

  Login(body: any) {
    return this.http.post('http://localhost:5001/api/v1/auth/login', body);
  }
  
  forgetPassword(body: any) {
    return this.http.post('http://localhost:5001/api/v1/auth/forgotpassword', body);
  }
  
  signup(body: any) {
    return this.http.post('http://localhost:5001/api/v1/auth/signup', body,
    {
      headers: {
        'Accept-Language':'en',
        'api-key':'Dashboard'
      }
      },
    
    );
  }

  getuserdetails() {
    return this.http.get('http://localhost:5001/api/v1/auth/userdetails');
  }

  logout() {
    return this.http.get('http://localhost:5001/api/v1/auth/logout');
  }

  deleteuser(id:any) {
    var ids = {
      "getid":id
    }
    return this.http.post('http://localhost:5001/api/v1/auth/deleteuser',ids);
  }

  updateUser(id:any,data:any) {
  data.id=id;
    return this.http.post('http://localhost:5001/api/v1/auth/updateUserDetails',data);
  }
  
  getSingleData(id:any) {
    var ids = {
      "id":id
    }
    return this.http.post('http://localhost:5001/api/v1/auth/getsingleuser',ids);
  }

  changepassword(data:any){
    return this.http.post('http://localhost:5001/api/v1/auth/changePassword',data);
  }

  getuserprofile(token:any) {
    return this.http.get('http://localhost:5001/api/v1/auth/getuserprofile',token);
  }
  dashboard() {
    return this.http.get('http://localhost:5001/api/v1/auth/dashboard');
  }



  
}

