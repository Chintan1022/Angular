import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import Swal from 'sweetalert2';
import { ServicesService } from '../services/services.service';
import { data } from 'jquery';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {
 readuser: any = []
 token=localStorage.getItem('token')

  constructor(private router:Router,private service:ServicesService) { }

ngOnInit(): void {
    this.service.getuserprofile(this.token).subscribe((res:any)=>{
     // console.log(res)
    this.readuser=res.data    
  })
}
confirmBox(){
  this.service.logout().subscribe(()=>{
  Swal.fire({
    title: 'Are you sure want to Logout?',
    icon: 'warning',
    showCancelButton: true,
    confirmButtonText: 'Yes, please!',
    cancelButtonText: 'No, keep it'
  })
  .then((result:any) => {
      if (result.value) {
        localStorage.removeItem('token');
        this.router.navigate(['login']);
      }
      else if (result.dismiss === Swal.DismissReason.cancel) {
       Swal.fire(
         'Cancelled',
         'error'
       )
    }
  })
})



}
 /* confirmBox(){
  this.service.logout().subscribe((res:any)=>{

    localStorage.removeItem('token');
    this.router.navigate(['login']);
  })
 } */
}
