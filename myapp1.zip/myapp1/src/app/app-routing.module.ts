import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HeaderComponent } from './header/header.component';
import { HomepageComponent } from './homepage/homepage.component';
import { LoginComponent } from './login/login.component';
import { PagenotfoundComponent } from './pagenotfound/pagenotfound.component';
import { SidebarComponent } from './sidebar/sidebar.component';
import { ChangepasswordComponent } from './changepassword/changepassword.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { OrdersComponent } from './orders/orders.component';
import { ProductsComponent } from './products/products.component';
import { CustomersComponent } from './customers/customers.component';
import { ProfileComponent } from './profile/profile.component';
import { ManageUsersComponent } from './manage-users/manage-users.component';
import { EdituserComponent } from './edituser/edituser.component';
import { SignupComponent } from './signup/signup.component';
import { ForgetpasswordComponent } from './forgetpassword/forgetpassword.component';
import { AuthGuard } from './auth/auth.guard';

const routes: Routes = [
  {
    path: '',
    component: LoginComponent
  },
  {
    path: 'signup',
    component: SignupComponent
  },
  {
    path: 'login',
    component: LoginComponent,
  },
  {
    path: 'login/forgetpassword',
    component: ForgetpasswordComponent,
  },
  
  {
    path: 'home',
    component: HomepageComponent,
    canActivate: [AuthGuard],
    children: [
      {
        path: 'header',
        component: HeaderComponent,

      },
      {
        path: 'sidebar',
        component: SidebarComponent
      },
      {
        path: 'dashboard',
       component: DashboardComponent 
      },
      {
        path: 'changepassword',
        component: ChangepasswordComponent
      },
      {
        path: 'orders',
        component: OrdersComponent
      },
      {
        path: 'products',
        component: ProductsComponent
      },
      {
        path: 'customers',
        component: CustomersComponent
      },
      {
        path: 'manageusers',
        component: ManageUsersComponent
      },
      {
        path: 'manageuser/:id',
        component: EdituserComponent
      },
      {
        path: 'profile',
        component: ProfileComponent
      },

      { path: '**', component: PagenotfoundComponent }

    ]
  },
  {
    path: '**',
    component: PagenotfoundComponent
  },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
