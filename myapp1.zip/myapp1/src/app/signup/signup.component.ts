import { Component, OnInit } from '@angular/core';
import{FormBuilder, FormControl,FormGroup, Validators} from'@angular/forms';
import { Router } from '@angular/router';
import { ConfirmedValidator } from "./confirmed.validator";
import { country } from './contry list';
import { ServicesService } from '../services/services.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {
  public signupForm!: FormGroup;
  public submitted = false;
 
  constructor(private formBuilder: FormBuilder, private router: Router,private service:ServicesService) { }

  countryList: country[] = [
    new country('1', 'India'),
    new country('2', 'USA'),
    new country('3', 'England'),
    new country('4', 'Caneda'),

  ];

  ngOnInit(): void {
    this.signupForm = this.formBuilder.group({
      name: ["", [Validators.required,Validators.pattern(
        "[a-zA-Z]+"
      )]],
      email: ["", [Validators.email, Validators.required]],
      role: ["",[Validators.required]],
      country: new FormControl('', [Validators.required]),
      phoneno: new FormControl('', [Validators.required,Validators.maxLength(10)]),
    
      password: ["",[Validators.required,Validators.pattern(
            "(?=.*[A-Za-z])(?=.*[0-9])(?=.*[$@$!#^~%*?&,.<>\"'\\;:{\\}\\[\\]\\|\\+\\-\\=\\_\\)\\(\\)\\`\\/\\\\\\]])[A-Za-z0-9d$@].{7,}"
          )
        ]
      ],
      acceptTerms: [false, Validators.requiredTrue],
      confirmpassword: ['', [Validators.required]]
    },
    {
      validator: ConfirmedValidator('password', 'confirmpassword')
    });


  }
  get formControl() {
    return this.signupForm.controls;
  }
  onsignup(value:any):void{
    this.submitted = true;
    if (this.signupForm.valid) {
      this.service.signup(value).subscribe(
        (response:any) => {
          if(response['code'] == 1){    
            Swal.fire({  
              position: 'center',  
              icon: 'success',  
              title: 'signup Success',  
              showConfirmButton: false,  
              timer: 1000  
            })        
            this.router.navigate(['home/dashboard'])
          }else{
            Swal.fire({  
              position: 'center',  
              icon: 'error',  
              title: 'something wrong',  
              showConfirmButton: false,  
              timer: 1000  
            })        
            this.ngOnInit();
          }
        
        });
 
      this.router.navigate(["/login"]);
    }
  }

}



