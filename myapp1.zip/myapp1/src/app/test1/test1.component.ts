import { Component, OnInit,Input } from '@angular/core';

@Component({
  selector: 'app-test1',
  templateUrl: './test1.component.html',
  styleUrls: ['./test1.component.css']
})
export class Test1Component implements OnInit {
  
  @Input() public parentData: any;
  constructor() { }

  ngOnInit(): void {
    
  }
  productSelected:boolean = false;
  selectedProduct:string | undefined;
  addedProduct:string | undefined;

  onSelectProduct(product: string | undefined){
    this.productSelected = true;
    this.selectedProduct = product
  }
  onAddProduct(){
    this.addedProduct = this.selectedProduct
  }

}
