export interface UserData { 
    id: number; 
    email: string; 
    name: string;
    phoneno: string;
    role: string; 


   
  }