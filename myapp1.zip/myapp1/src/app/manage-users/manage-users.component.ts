import { Component, OnDestroy, OnInit } from '@angular/core';
import { ServicesService } from '../services/services.service';
import { ToastrService } from 'ngx-toastr';
import { Subject } from 'rxjs';


@Component({
   selector: 'app-manage-users',
   templateUrl: './manage-users.component.html',
   styleUrls: ['./manage-users.component.css']
})
export class ManageUsersComponent implements OnInit, OnDestroy {
   dtOptions: DataTables.Settings = {};
   dtTrigger: Subject<any> = new Subject<any>();
   router: any;
   readuser: any = []
   constructor(private service: ServicesService, private toastr: ToastrService) { }
   
   ngOnDestroy(): void {
      this.dtTrigger.unsubscribe();
   }
   ngOnInit(): void {
      this.dtOptions = {
         pagingType: 'full_numbers'
      };
      this.users()
   }

   users(): void {
      this.service.getuserdetails().subscribe(
         (response: any) => {
            this.readuser = response.data
            this.dtTrigger.next(this.readuser);
         });
   }



   deleteuser(id: any) {
      this.service.deleteuser(id).subscribe((res: any) => {
         if (res['code'] == 1) {

            this.toastr.error('Delete user');
            this.ngOnInit();
         }
         else {
            console.log("fail")
         }
      })
   }

}
