import { Component, OnInit } from '@angular/core';
import { ServicesService } from '../services/services.service';
import { ActivatedRoute, Route, Router } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

import Swal from 'sweetalert2';

@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css']
})
export class ProfileComponent implements OnInit {
  submitted=false
  editprofileForm!: FormGroup ;
  token=localStorage.getItem('token')
  profile_image!:any
  id:any
  
  constructor(private service:ServicesService,private route:ActivatedRoute,private fb:FormBuilder,private router:Router) { }

  ngOnInit(): void {
    
      this.editprofileForm = this.fb.group({
        name:["", [Validators.required, Validators.pattern(
          "[a-zA-Z]+"
        )]],
        email:["", [Validators.email, Validators.required]],
        phoneno: ["", [Validators.required, Validators.maxLength(10)]],
      })
      this.service.getuserprofile(this.token).subscribe((res:any)=>{
        console.log(res)
        
        this.profile_image = res.data.profile_image;
        this.id=res.data.id;
        this.editprofileForm.patchValue({
          name:res.data.name,
          email:res.data.email,
          phoneno:res.data.phoneno,
        })     
    })
  }
  get formControl() {
    return this.editprofileForm.controls;
  }
  
  onSubmit() {
    this.submitted=true
    if(this.editprofileForm.valid){
      this.update();
    }
    else{
      console.log("false");
    }
  }

  update() {
    this.service.updateUser(this.id,this.editprofileForm.value).subscribe((res:any)=>{
      if(res['code'] == 1){    

        Swal.fire({  
          position: 'center',  
          icon: 'success',  
          title: 'Successfully Update user profile',  
          showConfirmButton: false,  
          timer: 1000  
        })        
        this.router.navigate(['home/dashboard'])
      }else{
        Swal.fire({  
          position: 'center',  
          icon: 'error',  
          title: 'Try Again !!!',  
          showConfirmButton: false,  
          timer: 1000  
        })        
        this.ngOnInit();
      }
    })
  }
    


}
