import { Component, OnInit } from '@angular/core';
import Swal from 'sweetalert2';
import { ServicesService } from '../services/services.service';
import { Router, Routes } from '@angular/router';

@Component({
  selector: 'app-forgetpassword',
  templateUrl: './forgetpassword.component.html',
  styleUrls: ['./forgetpassword.component.css']
})
export class ForgetpasswordComponent implements OnInit {

  constructor(private servies:ServicesService,private router: Router) { }

  ngOnInit(): void {
  }

  onSubmit(value: any) {
    this.servies.forgetPassword(value).subscribe(
      (response: any) => {
        if (response['code'] == 1) {
          Swal.fire({
            position: 'center',
            icon: 'success',
            title: 'Forgot Password Mail Sent Successfully',
            showConfirmButton: false,
            timer: 1000
          })
          this.router.navigate([''])
        } else {
          Swal.fire({
            position: 'center',
            icon: 'error',
            title:"Failed to sent forgot password mail, please try again. !!",
            showConfirmButton: false,
            timer: 1000
          })
          this.ngOnInit();
        }

      }

    );
 
  }

}
