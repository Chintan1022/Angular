import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { SidebarComponent } from './sidebar/sidebar.component';
import { LayoutModule } from '@angular/cdk/layout';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatButtonModule } from '@angular/material/button';
import { MatSidenavModule } from '@angular/material/sidenav';
import { MatIconModule } from '@angular/material/icon';
import { MatListModule } from '@angular/material/list';
import { DashboardComponent } from './dashboard/dashboard.component';
import { MatGridListModule } from '@angular/material/grid-list';
import { MatCardModule } from '@angular/material/card';
import { MatMenuModule } from '@angular/material/menu';
import { LoginComponent } from './login/login.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { DefaultComponent } from './default/default.component';
import {MatExpansionModule} from '@angular/material/expansion';
import { UserComponent } from './user/user.component';
import { HttpClientModule } from '@angular/common/http';
import { DataTablesModule } from "angular-datatables";
import { ViewuserComponent } from './viewuser/viewuser.component';
import { CategoryComponent } from './category/category.component';
import { EditcategoryComponent } from './editcategory/editcategory.component';
import { BlogComponent } from './blog/blog.component';
import { EditblogComponent } from './editblog/editblog.component';
import { PasswordComponent } from './password/password.component';
import { PagesComponent } from './pages/pages.component';
import { CKEditorModule } from 'ckeditor4-angular';
import { ReportsComponent } from './reports/reports.component';
import { QueriesComponent } from './queries/queries.component';
import { PostComponent } from './post/post.component';
import { GridModule,PDFModule,ExcelModule } from '@progress/kendo-angular-grid';
import { InputsModule } from '@progress/kendo-angular-inputs';
import { PagerModule } from '@progress/kendo-angular-pager';
import { NgHttpLoaderModule } from 'ng-http-loader';
import { ViewqueriesComponent } from './viewqueries/viewqueries.component';
import { ViewpostComponent } from './viewpost/viewpost.component';
import { SafePipeService } from './Service/safe-pipe.service';

import { HTTP_INTERCEPTORS } from '@angular/common/http';
import { TokenInterceptor } from './interceptors/auth-token.interceptor';



@NgModule({
  declarations: [
    AppComponent,
    SidebarComponent,
    DashboardComponent,
    LoginComponent,
    DefaultComponent,
    UserComponent,
    ViewuserComponent,
    CategoryComponent,
    EditcategoryComponent,
    BlogComponent,
    EditblogComponent,
    PasswordComponent,
    PagesComponent,
    ReportsComponent,
    QueriesComponent,
    PostComponent,
    ViewqueriesComponent,
    ViewpostComponent,
    SafePipeService
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    LayoutModule,
    MatToolbarModule,
    MatButtonModule,
    MatSidenavModule,
    MatIconModule,
    MatListModule,
    MatGridListModule,
    MatCardModule,
    MatMenuModule,
    FormsModule,
    MatExpansionModule,
    ReactiveFormsModule,
    HttpClientModule,
    DataTablesModule,
    CKEditorModule,
    GridModule,
    PDFModule,
    InputsModule,
    ExcelModule,
    PagerModule,
    NgHttpLoaderModule.forRoot(),
   ],
  providers: [
    {
      provide: HTTP_INTERCEPTORS,
      useClass: TokenInterceptor,
      multi: true
  }
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
