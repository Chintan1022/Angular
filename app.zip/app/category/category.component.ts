import { Component, OnInit } from '@angular/core';
import { AdminService } from '../Service/admin.service';
import Swal from 'sweetalert2';
import { process,SortDescriptor } from '@progress/kendo-data-query';
import { PageChangeEvent, PageSizeChangeEvent } from '@progress/kendo-angular-pager';

@Component({
  selector: 'app-category',
  templateUrl: './category.component.html',
  styleUrls: ['./category.component.css']
})
export class CategoryComponent implements OnInit {
  panelOpenState = false;

  // dtOptions:any = {};
  // dtTrigger: Subject<any> = new Subject<any>();
  loading = true;
  public img: any;
  imgURL: any = "assets/uploadimage.png";

  categoryData: any;
  public message: any ;
  imagePath: any;

  gridData: any;
  gridView: any;
  public pageSize = 5;
  public skip = 0;
  public pageSizeValues = [];
  public total = 10;

  constructor(private adminService: AdminService) { }


  public onPageChange(e: PageChangeEvent): void {
    this.skip = e.skip;
    this.pageSize = e.take;
    this.total = this.gridData.length

  }

public onPageSizeChange(e: PageSizeChangeEvent): void {}

 

  public sort: SortDescriptor[] = [];

  ngOnInit(): void {

    // this.dtOptions = {
    //   pagingType: 'full_numbers',
    //   pageLength: 10,
    //   lengthMenu: [5,10, 15, 20, 25, 30],
    //   processing: true,
    //   responsive:true
    // };

    this.adminService.Categorydata().subscribe(
      (response: any) => {
        this.categoryData = response.data;
        this.gridData = response.data;
        this.total = this.gridData.length
        this.pageSizeValues = this.gridData.slice(this.skip, this.skip + this.pageSize);

      });

  }


  public onFilter(inputValue: string): void {

    this.gridData = process(this.categoryData, {
      filter: {
        logic: "or",
        filters: [
          {
            field: 'en',
            operator: 'contains',
            value: inputValue
          },
          {
            field: 'es',
            operator: 'contains',
            value: inputValue
          },
          {
            field: 'fr',
            operator: 'contains',
            value: inputValue
          },

        ],
      }
    }).data;

  }


  // ngAfterViewInit(): void {
  //   setTimeout(() => {
  //     this.dtTrigger.next(this.dtOptions);
  //     // this.user = false;
  //   }, 100);

  // }

  // ngOnDestroy(): void {
  //   this.dtTrigger.unsubscribe();
  // }

  preview(files:any) {
    if (files.length === 0)
      return;
 
    var mimeType = files[0].type;
    if (mimeType.match(/image\/*/) == null) {
      this.message = "Only images are supported.";
      return;
    }

 
    var reader = new FileReader();
    this.imagePath = files;
       this.img =files[0];

    
    reader.readAsDataURL(files[0]); 
    reader.onload = (_event) => { 
      this.imgURL = reader.result; 
    }
  }



  onSubmit(value:any,categoryForm:any){
  
    this.loading = false;
    this.adminService.Addcategory(this.img,value).subscribe((response:any)=>{
    
      if(response['code'] == 1){
        this.loading = true;

        categoryForm.reset();

      Swal.fire({  
          position: 'center',  
          icon: 'success',  
          title: 'Category Added Successfully',  
          showConfirmButton: false,  
          timer: 1000  
        })            
        setTimeout(() => {
        location.reload();
          }, 200);

      }else{
        this.loading = true;

      }      

    });
   
  }





  confirmBox(id: any) {
    Swal.fire({
      title: 'Are you sure want to delete Category?',
      // text: 'You will not be able to recover this file!',
      icon: 'warning',
      showCancelButton: true,
      confirmButtonText: 'Yes, please!',
      cancelButtonText: 'No, keep it'
    }).then((result: any) => {
      if (result.value) {

        this.adminService.deletecategory(id).subscribe((response: any) => {

          if (response.code == 1) {
            Swal.fire({  
              position: 'center',  
              icon: 'success',  
              title: 'Category Deleted Successfully',  
              showConfirmButton: false,  
              timer: 1500  
            })        
            this.ngOnInit();
      
          } else {
            Swal.fire({  
              position: 'center',  
              icon: 'error',  
              title: 'oops something went wrong!!',  
              showConfirmButton: false,  
              timer: 1500  
            })        
          }          
        });

      } else if (result.dismiss === Swal.DismissReason.cancel) {
      }
    })
  }

}
