import { Component, OnInit } from '@angular/core';
import {  FormControl, FormGroup,FormBuilder } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { AdminService } from 'src/app/Service/admin.service';
import { Location } from '@angular/common'
import Swal from 'sweetalert2';


@Component({
  selector: 'app-viewuser',
  templateUrl: './viewuser.component.html',
  styleUrls: ['./viewuser.component.css']
})
export class ViewuserComponent implements OnInit {

  panelOpenState = false;

  userData: any;
  user = true;
  read = true;
  active = false;
  active_status:any;
  image_path: any;
  total_post = 0;
  total_comment= 0;
  total_reports=0;
  reportData: any;

  constructor(private route: ActivatedRoute,private router: Router, private adminService: AdminService,private location: Location) { }

  userdetails = new FormGroup({
    id: new FormControl(),
    username: new FormControl(),
    full_name: new FormControl(),
    phone: new FormControl(),
    email: new FormControl(),
    birth_date: new FormControl(),
    bio: new FormControl(),
    is_active: new FormControl(),
    device_name: new FormControl(),
    os_version: new FormControl(),
    app_version: new FormControl(),
    insert_date: new FormControl(),
    update_date: new FormControl(),
  });


  ngOnInit(): void {

    const id = this.route.snapshot.paramMap.get('id');

    this.adminService.Viewuser(id).subscribe(
      (response:any)=>{
        
        this.userData = response['data'].user[0];
        this.reportData = response['data'].report;
        this.total_post = this.userData.total_post
        this.total_comment = this.userData.total_comment
        this.total_reports = this.userData.total_reports

        
        if (this.userData.is_active === '1') {
          
          this.active = true;
          this.active_status = "Active"
        } else {
          this.active = false;
          this.active_status = "Inactive"

        }
        this.user = false;

        this.image_path = this.userData.profile_images;
        this.userdetails.controls['id'].disable();
        this.userdetails.controls['phone'].disable();
        this.userdetails.controls['email'].disable();
        this.userdetails.controls['device_name'].disable();
        this.userdetails.controls['insert_date'].disable();
        this.userdetails.controls['username'].disable();
        this.userdetails.controls['os_version'].disable();
        this.userdetails.controls['update_date'].disable();
        this.userdetails.patchValue(this.userData);

    });
    
  }


  edit(): void {
    this.read = !this.read;

  }

  back(){
    this.location.back()
  }

  sendemail(): void {

    this.adminService.sendwarning(this.userData).subscribe((response: any)=>{

        Swal.fire({  
          position: 'center',  
          icon: 'success',  
          title: 'Warning sent Successfully',  
          showConfirmButton: false,  
          timer: 1500  
        })            
   
   
      });

  }


  onSubmit(data:any){
    const id = this.route.snapshot.paramMap.get('id');
    
    this.adminService.Edituser(id,data).subscribe((response: any)=>{
      this.userData = response.data;
        this.ngOnInit();

        Swal.fire({  
          position: 'center',  
          icon: 'success',  
          title: 'User Updated Successfully',  
          showConfirmButton: false,  
          timer: 1500  
        })            
      });
  }


}
