import { HttpClient } from '@angular/common/http';
import { Component, Inject, OnInit } from '@angular/core';
import { AdminService } from 'src/app/Service/admin.service';
import Swal from 'sweetalert2';
import { process,SortDescriptor } from '@progress/kendo-data-query';
import { PageChangeEvent, PageSizeChangeEvent } from '@progress/kendo-angular-pager';

@Component({
  selector: 'app-queries',
  templateUrl: './queries.component.html',
  styleUrls: ['./queries.component.css']
})
export class QueriesComponent implements OnInit {
  contactData: any;
  gridData: any;
  gridView: any;
  public pageSize = 6;
  public skip = 0;
  public pageSizeValues = [];
  public total = 10;

  constructor(private adminService: AdminService, @Inject(HttpClient) private httpClient: HttpClient) { }
  


  public onPageChange(e: PageChangeEvent): void {
    this.skip = e.skip;
    this.pageSize = e.take;
    this.total = this.gridData.length

  }

  public onPageSizeChange(e: PageSizeChangeEvent): void {}
  public sort: SortDescriptor[] = [];

  ngOnInit(): void {

    this.adminService.contactData().subscribe(
      (response: any) => {
    
        this.contactData = response.data;
        this.gridData = response.data;
        this.total = this.gridData.length
        this.pageSizeValues = this.gridData.slice(this.skip, this.skip + this.pageSize);

      });
  }


  public onFilter(inputValue: string): void {

    this.gridData = process(this.contactData, {
      filter: {
        logic: "or",
        filters: [
          {
            field: 'full_name',
            operator: 'contains',
            value: inputValue
          },
          {
            field: 'user_id',
            operator: 'contains',
            value: inputValue
          },
          {
            field: 'email',
            operator: 'contains',
            value: inputValue
          },
          {
            field: 'subject',
            operator: 'contains',
            value: inputValue
          },
          {
            field: 'description',
            operator: 'contains',
            value: inputValue
          },
        ],
      }
    }).data;

  }



}

