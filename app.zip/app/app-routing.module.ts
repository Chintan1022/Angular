import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AuthGuard } from './Auth/auth.guard';
import { BlogComponent } from './blog/blog.component';
import { CategoryComponent } from './category/category.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { DefaultComponent } from './default/default.component';
import { EditblogComponent } from './editblog/editblog.component';
import { EditcategoryComponent } from './editcategory/editcategory.component';
import { LoginComponent } from './login/login.component';
import { PagesComponent } from './pages/pages.component';
import { PasswordComponent } from './password/password.component';
import { PostComponent } from './post/post.component';
import { QueriesComponent } from './queries/queries.component';
import { ReportsComponent } from './reports/reports.component';
import { SidebarComponent } from './sidebar/sidebar.component';
import { UserComponent } from './user/user.component';
import { ViewpostComponent } from './viewpost/viewpost.component';
import { ViewqueriesComponent } from './viewqueries/viewqueries.component';
import { ViewuserComponent } from './viewuser/viewuser.component';

const routes: Routes = [
  {
    path: '',
    component: LoginComponent,
  },
  {
    path:'login',
    component:LoginComponent
  },
  {
    path:'home',
    component:SidebarComponent,
    canActivate: [AuthGuard],
    children:[
      {
        path:'dashboard',
        component:DashboardComponent
      },
      {
        path:'user',
        component:UserComponent
      },
      {
        path:'user/:id',
        component:ViewuserComponent
      },
      {
        path:'category',
        component:CategoryComponent
      },
      {
        path:'category/:id',
        component:EditcategoryComponent
      },
      {
        path:'blog',
        component:BlogComponent
      },
      {
        path:'editblog/:id',
        component:EditblogComponent
      },
      {
        path:'password',
        component:PasswordComponent
      },
      {
        path:'pages',
        component:PagesComponent
      },
      {
        path:'reports',
        component:ReportsComponent
      },
      {
        path:'queries',
        component:QueriesComponent
      },
      {
        path:'queries/:id/:email/:fullname/:description/:subject',
        component:ViewqueriesComponent
      },
      {
        path:'post',
        component:PostComponent
      },
      {
        path:'post/:id',
        component:ViewpostComponent
      },
    ]
  },
  {
    path: '**',
    component: DefaultComponent,
  },
  
];

@NgModule({
  imports: [RouterModule.forRoot(routes,{ useHash: true })],
  exports: [RouterModule]
})
export class AppRoutingModule { }
