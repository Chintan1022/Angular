import { Component, OnInit } from '@angular/core';
import { AdminService } from 'src/app/Service/admin.service';
import { ActivatedRoute } from '@angular/router';
import { DomSanitizer } from '@angular/platform-browser';
import { Location } from '@angular/common'
import Swal from 'sweetalert2';

@Component({
  selector: 'app-viewpost',
  templateUrl: './viewpost.component.html',
  styleUrls: ['./viewpost.component.css']
})
export class ViewpostComponent implements OnInit {

  postData: any;
  media: any;
  description: any;
  avg_rating: any;
  category_image: any;
  category_id: any;
  category_name: any;
  insert_date: any;
  comment_count: any;
  expired_date: any;
  is_earth: any;
  is_expired: any;
  post_type: any;
  profile_image: any;
  privacy: any;
  time: any;
  update_date: any;
  username: any;
  total_reports: any;
  post_id: any;

  constructor(private adminService: AdminService,private route: ActivatedRoute,private sanitizer: DomSanitizer,private location: Location) { }

  ngOnInit(): void {
 
    const id = this.route.snapshot.paramMap.get('id');

    this.adminService.Viewpost(id).subscribe(
      (response: any) => {
        this.postData = response.data[0];

       this.post_id = this.postData.post_id
       this.media = this.postData.media
       this.description =   this.postData.description
       this.avg_rating =   this.postData.avg_rating
       this.category_id =   this.postData.category_id
       this.category_image =   this.postData.category_image
       this.comment_count =   this.postData.comment_count
       this.category_name =   this.postData.category_name
       this.expired_date =   this.postData.expired_date
       this.insert_date =   this.postData.insert_date
       this.is_earth =   this.postData.is_earth
       this.is_expired =   this.postData.is_expired
       this.post_type =   this.postData.post_type
       this.privacy =   this.postData.privacy
       this.profile_image =   this.postData.profile_image
       this.time =   this.postData.time
       this.update_date =   this.postData.update_date
       this.username =   this.postData.username
       this.total_reports =   this.postData.total_reports

      });
  }


  confirmBox(id: any,reason:any) {
    Swal.fire({
      title: 'Are you sure want to delete Post?',
      text: 'You will not be able to recover this post and it will be removed from the feeds!',
      icon: 'warning',
      showCancelButton: true,
      confirmButtonText: 'Yes, please!',
      cancelButtonText: 'No, keep it'
    }).then((result: any) => {
      if (result.value) {

        this.adminService.deletepost(id,reason,this.postData.username,this.postData.email).subscribe((response: any) => {

          if (response.code == 1) {
            Swal.fire({  
              position: 'center',  
              icon: 'success',  
              title: 'Post Deleted Successfully',  
              showConfirmButton: false,  
              timer: 1500  
            })        
         this.back()
          } else {
            Swal.fire({  
              position: 'center',  
              icon: 'error',  
              title: 'oops something went wrong!!',  
              showConfirmButton: false,  
              timer: 1500  
            })        
          }          
        });

      } else if (result.dismiss === Swal.DismissReason.cancel) {
      }
    })
  }


  back(){
    this.location.back()
  }


}

