import { Component, OnInit } from '@angular/core';
import { CKEditor4 } from 'ckeditor4-angular';
import { AdminService } from '../Service/admin.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-pages',
  templateUrl: './pages.component.html',
  styleUrls: ['./pages.component.css']
})
export class PagesComponent implements OnInit {
  panelOpenState = false;
  aboutus: any;
  privacy: any;
  faq: any;
  terms: any;
  data:any;

  constructor(public adminService:AdminService) { }



  ngOnInit(): void {

    this.adminService.CMSdata().subscribe((response:any)=>{
      
     this.aboutus = response['data'][0].content;
     this.privacy = response['data'][1].content;
     this.faq = response['data'][2].content;
     this.terms = response['data'][3].content;

     
    });

  }

  onChange( event: CKEditor4.EventInfo ) {
    this.data = event.editor.getData();        
  }



  save(type:any){

    console.log(type);
    console.log(this.data);
    
    

    if(this.data != undefined){
      
      this.adminService.CMS(type,this.data).subscribe((response:any)=>{  
      
      if(response.code ==1){
        Swal.fire({  
          position: 'center',  
          icon: 'success',  
          title: 'Data Updated Successfully',  
          showConfirmButton: false,  
          timer: 1000  
        })            
      }else{
        Swal.fire({  
          position: 'center',  
          icon: 'error',  
          title: 'oops something went wrong!!',  
          showConfirmButton: false,  
          timer: 1000  
        })     
      
      }
        });
    }

    
  }

}
