import { Injectable } from '@angular/core';
import { HttpRequest, HttpHandler, HttpEvent, HttpInterceptor, HttpErrorResponse } from '@angular/common/http';
import { catchError, Observable, throwError } from 'rxjs';
import { environment } from 'src/environments/environment';
import { Router } from '@angular/router';


@Injectable()
export class TokenInterceptor implements HttpInterceptor {
    constructor(private router: Router) { }

    intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
        request = request.clone({
            setHeaders: {
                'api-key': environment.APIKEY,
                'token': `${sessionStorage.getItem('token')}`
            }
        });
        return next.handle(request).pipe(
            catchError((response: HttpErrorResponse) => {
                if (response.status === 401) {
                    sessionStorage.removeItem('token')
                    this.router.navigate(['/login']);
                }
                return throwError(response);
            }
        ));   

    }

}