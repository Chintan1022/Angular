import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { AdminService } from 'src/app/Service/admin.service';
import { Location } from '@angular/common'
import Swal from 'sweetalert2';

@Component({
  selector: 'app-editcategory',
  templateUrl: './editcategory.component.html',
  styleUrls: ['./editcategory.component.css']
})
export class EditcategoryComponent implements OnInit {
  message: any;
  imgURL: any = "assets/uploadimage.png";
  imagePath: any;
  img: any;
  loading = true;
  categoryData: any;
  en: any;
  es: any;
  fr: any;

  constructor(private adminService: AdminService,private route: ActivatedRoute,private router: Router,private location: Location) { }


  preview(files:any) {
    if (files.length === 0)
      return;
 
    var mimeType = files[0].type;
    if (mimeType.match(/image\/*/) == null) {
      this.message = "Only images are supported.";
      return;
    }
 
    var reader = new FileReader();
    this.imagePath = files;
       this.img =files[0];

    reader.readAsDataURL(files[0]); 
    reader.onload = (_event) => { 
      this.imgURL = reader.result; 
      
    }
  }


  ngOnInit(): void {
    var id = this.route.snapshot.paramMap.get('id');

    this.adminService.Categoryview(id).subscribe(
      (response: any) => {

        this.categoryData = response.data[0];
        this.imgURL = this.categoryData.category_images;
        this.en = this.categoryData.en;
        this.es = this.categoryData.es;
        this.fr = this.categoryData.fr;
         

      });


  }



  onSubmit(value:any){
    this.loading = false;
    var id = this.route.snapshot.paramMap.get('id');


    this.adminService.Editcategory(this.img,value,id).subscribe((response:any)=>{
    
      if(response['code'] == 1){
        this.loading = true;

        Swal.fire({  
          position: 'center',  
          icon: 'success',  
          title: 'Category Updated Successfully',  
          showConfirmButton: false,  
          timer: 1500  
        })    

        this.ngOnInit();

      }else{
        this.loading = true;

      }      

    });
  }


  back(){
    this.location.back()
  }

}
