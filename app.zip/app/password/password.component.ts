import { Component, OnInit } from '@angular/core';
import { AdminService } from '../Service/admin.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-password',
  templateUrl: './password.component.html',
  styleUrls: ['./password.component.css']
})
export class PasswordComponent implements OnInit {

  constructor(private adminservice: AdminService) { }

  ngOnInit(): void {
  }

  onSubmitReset(value:any,ResetForm:any){

    this.adminservice.Chnagepassword(value).subscribe((response:any)=>{

      ResetForm.reset();


      if(response == 1){
        Swal.fire({  
          position: 'center',  
          icon: 'success',  
          title: 'Password Chnaged Successfully","Please login again',  
          showConfirmButton: false,  
          timer: 1500  
        })            
      
      }else{
        Swal.fire({  
          position: 'center',  
          icon: 'error',  
          title: 'Fails!!", "Incurrect Old Password !!',  
          showConfirmButton: false,  
          timer: 1500  
        })                  
      }
    })
  
    
  }

}
