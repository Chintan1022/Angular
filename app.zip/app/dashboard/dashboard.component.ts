import { Component, OnInit } from '@angular/core';
import { AdminService } from '../Service/admin.service';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})


  export class DashboardComponent implements OnInit  {
    total_user: any;
    total_post: any;
    total_ads: any;
    total_blogs: any;
    total_subadmin: any;
    total_reports: any;
    
  
    constructor(private adminService:AdminService) { }
  
    ngOnInit(): void {

      this.adminService.Dashboard().subscribe(
        (response: any) => {
          this.total_user = response.data[0].total_user;
          this.total_post = response.data[0].total_post;
          this.total_ads = response.data[0].total_ads;
          this.total_blogs = response.data[0].total_blogs;
          this.total_reports = response.data[0].total_reports;
          this.total_subadmin = response.data[0].total_subadmin;

        });
  
  
    }
  }