import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment';


@Injectable({
  providedIn: 'root'
})
export class AdminService {

  constructor(private http: HttpClient) { }
  body = ['key', 'val'];
  token = sessionStorage.getItem('token') || "";


  Login(body: any) {
    return this.http.post(environment.APIURL + '/login', body,
      // {
      //   headers: {
      //     'api-key': environment.APIKEY,
      //     // 'token':this.token
      //   }
      // },
    );
  }

  Dashboard() {

    if (this.token == '') {
      this.token = sessionStorage.getItem('token') || "";
    }
      return this.http.get(environment.APIURL + '/dashboard',);

  }

  Userdata() {

    return this.http.get(environment.APIURL + '/userdata',);
  }

  deluser(id: any) {

    return this.http.get(environment.APIURL + '/deleteuser/' + id,);

  }

  Viewuser(id: any) {

    return this.http.get(environment.APIURL + '/userdetail/' + id,);
  }

  Edituser(id: any, data: any) {

    return this.http.post(environment.APIURL + '/edituser/' + id, data,);

  }

  Categorydata() {

    return this.http.get(environment.APIURL + '/categorydata',);
  }

  deletecategory(id: any) {
    return this.http.delete(environment.APIURL + '/deletecategory/' + id,);
  }

  blogData() {

    return this.http.get(environment.APIURL + '/blogdata',);
  }

  Addcategory(body: File, value: any) {

    const formData = new FormData();
    formData.append('img', body);
    formData.append('en', value.en);
    formData.append('es', value.es);
    formData.append('fr', value.fr);

    return this.http.post(environment.APIURL + '/addcategory', formData,);
  }


  Categoryview(id: any) {

    return this.http.get(environment.APIURL + '/categoryview/' + id,);
  }

  Editcategory(body: File, value: any, id: any) {
    var formDatas;
    if (body == undefined) {
      formDatas = {
        "en": value.en,
        "es": value.es,
        "fr": value.fr,
        "id": id,
        "img": ""
      }
    } else {
      formDatas = new FormData();
      formDatas.append('img', body);
      formDatas.append('id', id);
      formDatas.append('en', value.en);
      formDatas.append('es', value.es);
      formDatas.append('fr', value.fr);

    }
    return this.http.post(environment.APIURL + '/editcategory', formDatas,);
  }

  Addblog(body: File, value: any) {

    const formData = new FormData();
    formData.append('img', body);
    formData.append('title', value.title);
    formData.append('description', value.description);

    return this.http.post(environment.APIURL + '/addblog', formData,);
  }


  Blogview(id: any) {

    return this.http.get(environment.APIURL + '/blogview/' + id,);
  }

  Editblog(body: File, value: any, id: any) {
    var formDatas;
    if (body == undefined) {
      formDatas = {
        "title": value.title,
        "description": value.description,
        "id": id,
        "img": ""
      }
    } else {
      formDatas = new FormData();
      formDatas.append('img', body);
      formDatas.append('id', id);
      formDatas.append('title', value.title);
      formDatas.append('description', value.description);

    }
    return this.http.post(environment.APIURL + '/editblog', formDatas,);
  }

  deleteblog(id: any) {
    return this.http.delete(environment.APIURL + '/deleteblog/' + id,);
  }


  Chnagepassword(value: any) {

    return this.http.post(environment.APIURL + '/chnagepassword/', value,);
  }


  CMSdata() {

    return this.http.get(environment.APIURL + '/cmsdata',);
  }

  CMS(title: any, data: any) {
    data = {
      "content": data
    }
    return this.http.post(environment.APIURL + '/cms/' + title, data,);
  }

  contactData() {

    return this.http.get(environment.APIURL + '/contactdata',);
  }

  reportData() {

    return this.http.get(environment.APIURL + '/reportdata',);
  }


  Postdata() {

    return this.http.get(environment.APIURL + '/postdata',);
  }

  Viewpost(id: any) {

    return this.http.get(environment.APIURL + '/postdetail/' + id,);
  }


  deletepost(id: any, reason: any, username: any, email: any) {
    reason = {
      "reason": reason,
      "username": username,
      "email": email
    }
    return this.http.post(environment.APIURL + '/deletepost/' + id, reason,);
  }

  sendwarning(data: any) {

    return this.http.post(environment.APIURL + '/sendwarning/', data,);
  }

  sendquery(data: any, email: any, fullname: any, description: any, subject: any, id: any) {

    data = {
      contend: data,
      email: email,
      fullname: fullname,
      description: description,
      subject: subject,
      id: id
    }

    return this.http.post(environment.APIURL + '/sendquery/', data,);
  }
}
