import { Component, OnInit } from '@angular/core';
import { CKEditor4 } from 'ckeditor4-angular';
import { AdminService } from '../Service/admin.service';
import Swal from 'sweetalert2';
import { ActivatedRoute } from '@angular/router';
import { Location } from '@angular/common'

@Component({
  selector: 'app-viewqueries',
  templateUrl: './viewqueries.component.html',
  styleUrls: ['./viewqueries.component.css']
})
export class ViewqueriesComponent implements OnInit {

  data:any;
  id:any;
  email:any;
  fullname:any;
  description:any;
  subject:any;


  constructor(public adminService: AdminService,private route: ActivatedRoute,private location: Location) { }

  ngOnInit(): void {
    this.id = this.route.snapshot.paramMap.get('id');
    this.email = this.route.snapshot.paramMap.get('email');
    this.fullname = this.route.snapshot.paramMap.get('fullname');
    this.description = this.route.snapshot.paramMap.get('description');
    this.subject = this.route.snapshot.paramMap.get('subject');

  }

  onChange(event: CKEditor4.EventInfo) {
    this.data = event.editor.getData();

  }


  save() {

    if (this.data != undefined) {

      this.adminService.sendquery(this.data,this.email,this.fullname,this.description,this.subject,this.id).subscribe((response: any) => {
        if (response.code == 1) {
          Swal.fire({
            position: 'center',
            icon: 'success',
            title: 'Email Sent Successfully',
            showConfirmButton: false,
            timer: 1000
          })
          this.back()
        } else {
          Swal.fire({
            position: 'center',
            icon: 'error',
            title: 'oops something went wrong!!',
            showConfirmButton: false,
            timer: 1000
          })
        }
      });
    }
  }


  back(){
    this.location.back()
  }

}
