import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { AdminService } from 'src/app/Service/admin.service';
import { Location } from '@angular/common'
import Swal from 'sweetalert2';

@Component({
  selector: 'app-editblog',
  templateUrl: './editblog.component.html',
  styleUrls: ['./editblog.component.css']
})
export class EditblogComponent implements OnInit {

  message: any;
  imgURL: any = "assets/uploadimage.png";
  imagePath: any;
  img: any;
  loading = true;
  blogData: any;
  title: any;
  description: any;

  constructor(private adminService: AdminService,private route: ActivatedRoute,private router: Router,private location: Location) { }


  preview(files:any) {
    if (files.length === 0)
      return;
 
    var mimeType = files[0].type;
    if (mimeType.match(/image\/*/) == null) {
      this.message = "Only images are supported.";
      return;
    }
 
    var reader = new FileReader();
    this.imagePath = files;
       this.img =files[0];

    reader.readAsDataURL(files[0]); 
    reader.onload = (_event) => { 
      this.imgURL = reader.result; 
      
    }
  }


  ngOnInit(): void {
    var id = this.route.snapshot.paramMap.get('id');

    this.adminService.Blogview(id).subscribe(
      (response: any) => {
      console.log("🚀 ~ file: editblog.component.ts ~ line 53 ~ EditblogComponent ~ ngOnInit ~ response", response)

        this.blogData = response.data[0];
        this.imgURL = this.blogData.images;
        this.title = this.blogData.title;
        this.description = this.blogData.description;

      });
  }



  onSubmit(value:any){
    this.loading = false;
    var id = this.route.snapshot.paramMap.get('id');

    this.adminService.Editblog(this.img,value,id).subscribe((response:any)=>{
    
      if(response['code'] == 1){
        this.loading = true;

        Swal.fire({  
          position: 'center',  
          icon: 'success',  
          title: 'Blog Updated Successfully',  
          showConfirmButton: false,  
          timer: 1500  
        })    

        this.ngOnInit();

      }else{
        this.loading = true;

      }      

    });
  }


  back(){
    this.location.back()
  }

}
