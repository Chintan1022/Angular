import { HttpClient } from '@angular/common/http';
import { Component, Inject, OnInit } from '@angular/core';
import { AdminService } from 'src/app/Service/admin.service';
import Swal from 'sweetalert2';
import { process,SortDescriptor } from '@progress/kendo-data-query';
import { PageChangeEvent, PageSizeChangeEvent } from '@progress/kendo-angular-pager';

@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.css']
})
export class UserComponent implements OnInit {

  // dtOptions: any = {};
  // dtTrigger: Subject<any> = new Subject<any>();
  userData: any;
  user = true;
  gridData: any;
  gridView: any;
  public pageSize = 6;
  public skip = 0;
  public pageSizeValues = [];
  public total = 10;


  constructor(private adminService: AdminService, @Inject(HttpClient) private httpClient: HttpClient) { }


  public onPageChange(e: PageChangeEvent): void {
    this.skip = e.skip;
    this.pageSize = e.take;
    this.total = this.gridData.length

  }

  public onPageSizeChange(e: PageSizeChangeEvent): void {}
  public sort: SortDescriptor[] = [];


  ngOnInit() {

    // this.dtOptions = {
    //   pagingType: 'full_numbers',
    //   pageLength: 10,
    //   lengthMenu: [10, 15, 20, 25, 30],
    //   processing: true,

    //   dom: 'Bfltip',
    //   buttons: [
    //     'print',
    //     'excel',

    //   ],
    //   responsive: true

    // };

    this.adminService.Userdata().subscribe(
      (response: any) => {
    
        this.userData = response.data;
        this.gridData = response.data;
        this.total = this.gridData.length
        this.pageSizeValues = this.gridData.slice(this.skip, this.skip + this.pageSize);

      });



  }



  public onFilter(inputValue: string): void {

    this.gridData = process(this.userData, {
      filter: {
        logic: "or",
        filters: [
          {
            field: 'full_name',
            operator: 'contains',
            value: inputValue
          },
          {
            field: 'email',
            operator: 'contains',
            value: inputValue
          },
          {
            field: 'username',
            operator: 'contains',
            value: inputValue
          },
          {
            field: 'full_name',
            operator: 'contains',
            value: inputValue
          },

        ],
      }
    }).data;

  }


  // ngAfterViewInit(): void {

  //   setTimeout(() => {
  //     this.dtTrigger.next(this.dtOptions);
  //     this.user = false;
  //   }, 100);

  // }

  confirmBox(id: any) {
    Swal.fire({
      title: 'Are you sure want to delete user?',
      // text: 'You will not be able to recover this file!',
      icon: 'warning',
      showCancelButton: true,
      confirmButtonText: 'Yes, please!',
      cancelButtonText: 'No, keep it'
    }).then((result: any) => {
      if (result.value) {

        this.adminService.deluser(id).subscribe((response: any) => {

          if (response.code == 1) {
            Swal.fire({
              position: 'center',
              icon: 'success',
              title: 'User Deleted Successfully',
              showConfirmButton: false,
              timer: 1500
            })
            this.ngOnInit();
    
          } else {
            Swal.fire({
              position: 'center',
              icon: 'error',
              title: 'oops something went wrong!!',
              showConfirmButton: false,
              timer: 1500
            })
          }
        });

      } else if (result.dismiss === Swal.DismissReason.cancel) {
      }
    })
  }


  // ngOnDestroy(): void {
  //   this.dtTrigger.unsubscribe();
  // }

}
