import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'app-mini-card',
  templateUrl: './mini-card.component.html',
  styleUrls: ['./mini-card.component.css']
})
export class MiniCardComponent implements OnInit {
 @Input()  icon: string | undefined;
  @Input() title: string | undefined;
  @Input() value: number | undefined;
  @Input() color: string | undefined;
  @Input() isIncrease: boolean | undefined;
  @Input() isCurrency: boolean | undefined;
  @Input() duration: string | undefined;
  @Input() percentValue: number | undefined;
  constructor() { }

  ngOnInit(): void {
  }

}
