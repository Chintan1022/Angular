export class StoreSummary {
    title!: string;
    value!: any;
    isIncrease!: boolean;
    color!: string;
    percentValue!: any;
    icon!: string;
    isCurrency!: boolean;
}