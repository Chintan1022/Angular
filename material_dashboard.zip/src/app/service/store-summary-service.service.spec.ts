import { TestBed } from '@angular/core/testing';

import { StoreSummaryServiceService } from './store-summary-service.service';

describe('StoreSummaryServiceService', () => {
  let service: StoreSummaryServiceService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(StoreSummaryServiceService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
