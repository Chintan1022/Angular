import { TestBed } from '@angular/core/testing';

import { ServiceorderserviceService } from './serviceorderservice.service';

describe('ServiceorderserviceService', () => {
  let service: ServiceorderserviceService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ServiceorderserviceService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
