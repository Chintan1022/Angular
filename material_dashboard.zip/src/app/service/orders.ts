export class Order {
    id!: number;
    date!: string;
    name!: string;
    status!: string;
    orderTotal!: number;
    paymentMode!: string;
}