import { Component } from '@angular/core';

@Component({
  selector: 'app-floating-labels',
  templateUrl: './floating-labels.component.html',
  styleUrls: ['./floating-labels.component.scss']
})
export class FloatingLabelsComponent {

  constructor() { }

}
